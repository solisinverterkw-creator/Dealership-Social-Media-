<?php
header('Content-Type: application/json');
require_once __DIR__ . '/includes/Auth.php';
if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit;
}
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/InstagramLookup.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID missing']);
    exit;
}
if (!Auth::canAccessDealership((int)$id)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}
if (!Auth::can('refresh')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You Do Not Have Permission To Refresh Data.']);
    exit;
}

$db = Database::getConnection();
$stmt = $db->prepare("SELECT ig_search, ig_followers FROM dealerships WHERE id = :id");
$stmt->execute(['id' => $id]);
$d = $stmt->fetch();

if (!$d) {
    echo json_encode(['success' => false, 'message' => 'Dealership Not Found']);
    exit;
}

if (empty($d['ig_search'])) {
    echo json_encode(['success' => true, 'skipped' => true, 'ig_followers' => (int)$d['ig_followers']]);
    exit;
}

$ig = (new InstagramLookup())->getFollowerCount($d['ig_search']);
if (!$ig['success']) {
    echo json_encode(['success' => false, 'message' => $ig['message'], 'ig_followers' => (int)$d['ig_followers']]);
    exit;
}

$db->prepare("UPDATE dealerships SET ig_followers = :v, last_refreshed = NOW() WHERE id = :id")
   ->execute(['v' => $ig['followers'], 'id' => $id]);

echo json_encode(['success' => true, 'ig_followers' => $ig['followers']]);
