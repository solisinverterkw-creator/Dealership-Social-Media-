<?php
header('Content-Type: application/json');
require_once __DIR__ . '/includes/Auth.php';
if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit;
}
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/FacebookPostsLookup.php';
set_time_limit(0); // Bright Data can take longer than PHP's default execution limit if it falls back to polling

$db = Database::getConnection();
$settings = $db->query("SELECT setting_key, setting_value FROM app_settings WHERE setting_key IN ('source_page_url', 'source_page_id')")
    ->fetchAll(PDO::FETCH_KEY_PAIR);

$sourceUrl = $settings['source_page_url'] ?? null;
$sourcePageId = $settings['source_page_id'] ?? null;

if (empty($sourceUrl)) {
    echo json_encode(['success' => false, 'message' => 'Source Page Not Set Yet.']);
    exit;
}

$from = $_GET['from'] ?? null;
$to = $_GET['to'] ?? null;

$lookup = new FacebookPostsLookup();
$result = ($from && $to)
    ? $lookup->getPostsInRange($sourceUrl, $from, $to, $sourcePageId)
    : $lookup->getRecentPosts($sourceUrl, 10, $sourcePageId);

if (!$result['success']) {
    echo json_encode(['success' => false, 'message' => $result['message']]);
    exit;
}

$isProcessed = $db->prepare("SELECT 1 FROM processed_source_posts WHERE source_post_id = :id");

$posts = [];
foreach ($result['posts'] as $post) {
    $isProcessed->execute(['id' => $post['id']]);
    $posts[] = [
        'id' => $post['id'],
        'message' => $post['message'],
        'image_url' => $post['image_url'],
        'video_url' => $post['video_url'],
        'created_time' => $post['created_time'],
        'source_url' => $post['source_url'],
        'is_processed' => (bool)$isProcessed->fetch(),
    ];
}

echo json_encode(['success' => true, 'posts' => $posts, 'source_url' => $sourceUrl]);
