<?php
require_once __DIR__ . '/includes/Auth.php';
Auth::requireLogin();
require_once __DIR__ . '/includes/Database.php';

$db = Database::getConnection();
$scopedIds = Auth::dealershipIds();
$isSuperAdmin = Auth::isSuperAdmin();

if ($isSuperAdmin) {
    $targetPages = $db->query("SELECT * FROM target_pages WHERE is_active = 1 ORDER BY name")->fetchAll();
} elseif (empty($scopedIds)) {
    $targetPages = [];
} else {
    $placeholders = implode(',', array_fill(0, count($scopedIds), '?'));
    $stmt = $db->prepare("SELECT * FROM target_pages WHERE is_active = 1 AND dealership_id IN ($placeholders) ORDER BY name");
    $stmt->execute($scopedIds);
    $targetPages = $stmt->fetchAll();
}
$sourceUrlSetting = $db->query("SELECT setting_value FROM app_settings WHERE setting_key = 'source_page_url'")->fetchColumn();
$zapierPageCount = (int)($db->query("SELECT setting_value FROM app_settings WHERE setting_key = 'zapier_connected_pages_count'")->fetchColumn() ?: 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<script>(function(){var t=localStorage.getItem('theme');if(t)document.documentElement.setAttribute('data-theme',t);})();</script>
<meta charset="UTF-8">
<title>Publish Content</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#1a1a19">
<link rel="apple-touch-icon" href="assets/icon-192.png">
<script>if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js'));}</script>
</head>
<body>
<div class="app-layout">
<?php require __DIR__ . '/includes/Sidebar.php'; ?>
<main class="main-content">
<div class="container">

  <div class="search-panel" style="margin-bottom:24px; display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
    <div class="field" style="margin-bottom:0;">
      <label>Source Page From</label>
      <input type="date" id="source-from-input">
    </div>
    <div class="field" style="margin-bottom:0;">
      <label>Source Page To</label>
      <input type="date" id="source-to-input">
    </div>
    <button type="button" class="submit" style="width:auto; padding:11px 24px;" onclick="loadRecentPosts(this)">Load By Date Range</button>
  </div>

  <header>
    <div>
      <h1>Publish Content</h1>
      <div class="subtitle">Source Page's Recent Posts — Publish New Ones To All Active Dealer Pages</div>
    </div>
    <div class="toolbar">
      <button class="btn primary" id="load-posts-btn" onclick="loadRecentPosts(this)">Check Source Page Now</button>
    </div>
  </header>

  <?php if ($isSuperAdmin): ?>
  <div class="search-panel" style="margin-bottom:24px;">
    <div class="field" style="flex:1;">
      <label>Source Page URL</label>
      <input type="text" id="source-url-input" value="<?= htmlspecialchars($sourceUrlSetting ?? '') ?>" placeholder="https://www.facebook.com/YourSourcePage">
    </div>
    <button type="button" class="submit" onclick="saveSourceUrl()">Save</button>
  </div>
  <div id="source-url-msg" style="margin-bottom:16px;"></div>

  <div class="search-panel" style="margin-bottom:24px;">
    <div class="field">
      <label>Zapier-Connected Pages (Update Manually As You Add Dealerships In Zapier)</label>
      <input type="number" id="zapier-count-input" value="<?= $zapierPageCount ?>" min="0" style="max-width:120px;">
    </div>
    <button type="button" class="submit" onclick="saveZapierCount()">Save</button>
  </div>
  <div id="zapier-count-msg" style="margin-bottom:16px;"></div>
  <?php endif; ?>

  <?php if (empty($targetPages) && ($isSuperAdmin ? $zapierPageCount === 0 : true)): ?>
    <div class="empty-state"><?= $isSuperAdmin ? 'No Active Target Pages. Add Some In "Target Pages" First.' : 'No Target Page Linked To Your Dealership Yet. Contact Your Super Admin.' ?></div>
  <?php else: ?>

  <div class="subtitle" style="margin-bottom:16px;">
    <?php if ($isSuperAdmin): ?>
      <?= count($targetPages) ?> Direct Page(s) + <?= $zapierPageCount ?> Via Zapier = <?= count($targetPages) + $zapierPageCount ?> Total Dealer Page(s) Will Receive New Posts.
    <?php else: ?>
      New Posts Will Be Published To Your Dealership Page.
    <?php endif; ?>
  </div>

  <div id="posts-list"></div>

  <?php endif; ?>

</div>
</main>
</div>

<script>
const isSuperAdmin = <?= $isSuperAdmin ? 'true' : 'false' ?>;
const targetCount = <?= count($targetPages) ?>;
const zapierCount = <?= $zapierPageCount ?>;
const totalCount = isSuperAdmin ? (targetCount + zapierCount) : targetCount;
const publishButtonLabel = isSuperAdmin ? `Publish To All ${totalCount} Dealer Page(s)` : 'Publish To My Page';

async function loadRecentPosts(btnEl) {
  btnEl = btnEl || document.getElementById('load-posts-btn');
  const originalText = btnEl.textContent;
  btnEl.disabled = true;
  btnEl.textContent = 'Checking...';

  const listEl = document.getElementById('posts-list');
  listEl.innerHTML = '';

  const from = document.getElementById('source-from-input')?.value;
  const to = document.getElementById('source-to-input')?.value;
  const usingRange = Boolean(from && to);
  const url = usingRange
    ? `fetch_source_recent_posts.php?from=${from}&to=${to}`
    : 'fetch_source_recent_posts.php';

  try {
    const res = await fetch(url);
    const data = await res.json();

    if (!data.success) {
      listEl.innerHTML = `<div class="error-msg">${data.message}</div>`;
      return;
    }

    if (data.posts.length === 0) {
      listEl.innerHTML = `<div class="empty-state">No Posts Found ${usingRange ? 'In This Date Range' : 'On The Source Page'}.</div>`;
      return;
    }

    data.posts.forEach(post => {
      listEl.appendChild(buildPostCard(post));
    });
  } catch (e) {
    listEl.innerHTML = `<div class="error-msg">Could Not Reach The Source Page.</div>`;
  } finally {
    btnEl.disabled = false;
    btnEl.textContent = originalText;
  }
}

function buildPostCard(post) {
  const card = document.createElement('div');
  card.className = 'detail-card';
  card.id = `post-card-${post.id}`;

  const dateStr = post.created_time ? new Date(post.created_time).toLocaleString() : '';
  const statusBadge = post.is_processed
    ? '<span class="status-badge status-done">Already Published</span>'
    : '<span class="status-badge status-partial">New — Not Yet Published</span>';

  card.innerHTML = `
    <h2 style="display:flex; justify-content:space-between; align-items:center; font-size:14px;">
      <span>${dateStr}</span>
      ${statusBadge}
    </h2>
    <p style="margin:12px 0; font-size:13px; white-space:pre-wrap;">${escapeHtml(post.message || '(No Text)')}</p>
    ${post.image_url ? `<img src="${post.image_url}" style="max-width:280px; border-radius:6px; border:1px solid var(--border); margin-bottom:12px;">` : ''}
    ${post.video_url ? `<video src="${post.video_url}" controls style="max-width:280px; border-radius:6px; border:1px solid var(--border); margin-bottom:12px;"></video>` : ''}
    <div>
      <button class="btn primary" ${post.is_processed || totalCount === 0 ? 'disabled' : ''} onclick='publishPost(${JSON.stringify(post)})'>
        ${publishButtonLabel}
      </button>
    </div>
    <div class="progress-wrap" id="progress-wrap-${post.id}" style="display:none; margin-top:14px;">
      <div class="progress-bar-track"><div class="progress-bar-fill" id="progress-bar-fill-${post.id}" style="width:0%"></div></div>
      <div class="progress-text" id="progress-text-${post.id}"></div>
    </div>
  `;
  return card;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function publishPost(post) {
  const card = document.getElementById(`post-card-${post.id}`);
  const btn = card.querySelector('button.btn.primary');
  btn.disabled = true;

  const progressWrap = document.getElementById(`progress-wrap-${post.id}`);
  const progressFill = document.getElementById(`progress-bar-fill-${post.id}`);
  const progressText = document.getElementById(`progress-text-${post.id}`);
  progressWrap.style.display = 'block';

  await publishToAllTargets(post, progressFill, progressText, btn);
}

async function publishToAllTargets(post, progressFill, progressText, btn) {
  const res = await fetch('fetch_target_ids.php');
  const targets = await res.json();

  let done = 0;
  let failed = 0;
  for (const target of targets.targets) {
    const percent = Math.round((done / targets.targets.length) * 100);
    progressFill.style.width = `${percent}%`;
    progressText.textContent = `${percent}% Complete — Publishing To ${target.name} (${done + 1}/${targets.targets.length})`;
    btn.textContent = `Publishing ${done + 1}/${targets.targets.length}...`;

    try {
      const r = await fetch('publish_post.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          target_id: target.id,
          message: post.message || '',
          image_url: post.image_url || '',
          video_url: post.video_url || '',
          source_post_id: post.id,
          source_url: post.source_url,
        }),
      });
      const data = await r.json();
      if (!data.success) failed++;
    } catch (e) {
      failed++;
    }

    done++;
    await new Promise(r => setTimeout(r, 500));
  }

  let zapierAttempted = 0;
  if (isSuperAdmin) {
    zapierAttempted = 1;
    progressText.textContent = `Sending To Zapier...`;
    try {
      const zr = await fetch('send_to_zapier.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          message: post.message || '',
          image_url: post.image_url || '',
          video_url: post.video_url || '',
          source_post_id: post.id,
          source_url: post.source_url,
        }),
      });
      const zdata = await zr.json();
      if (!zdata.success) failed++;
    } catch (e) {
      failed++;
    }
  }

  progressFill.style.width = '100%';
  progressText.textContent = `100% Complete — ${done + zapierAttempted - failed}/${done + zapierAttempted} Published, ${failed} Failed`;

  await fetch('mark_source_post_processed.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ source_post_id: post.id, message_snippet: post.message || '' }),
  });

  btn.textContent = 'Published';
}

async function saveSourceUrl() {
  const input = document.getElementById('source-url-input');
  const msgEl = document.getElementById('source-url-msg');
  const url = input.value.trim();
  if (!url) {
    msgEl.innerHTML = `<div class="error-msg">Source Page URL Is Empty.</div>`;
    return;
  }

  msgEl.innerHTML = `<div class="subtitle">Checking...</div>`;
  try {
    const res = await fetch('update_source_page_url.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ url }),
    });
    const data = await res.json();
    if (!data.success) {
      msgEl.innerHTML = `<div class="error-msg">${data.message}</div>`;
      return;
    }
    msgEl.innerHTML = `<div class="success-msg">Source Page Saved.</div>`;
    loadRecentPosts();
  } catch (e) {
    msgEl.innerHTML = `<div class="error-msg">Could Not Save Source Page.</div>`;
  }
}

async function saveZapierCount() {
  const input = document.getElementById('zapier-count-input');
  const msgEl = document.getElementById('zapier-count-msg');
  const count = parseInt(input.value, 10) || 0;

  msgEl.innerHTML = `<div class="subtitle">Saving...</div>`;
  try {
    const res = await fetch('update_zapier_count.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ count }),
    });
    const data = await res.json();
    if (!data.success) {
      msgEl.innerHTML = `<div class="error-msg">${data.message}</div>`;
      return;
    }
    msgEl.innerHTML = `<div class="success-msg">Saved. Refresh The Page To See Updated Totals.</div>`;
  } catch (e) {
    msgEl.innerHTML = `<div class="error-msg">Could Not Save.</div>`;
  }
}

// Does NOT auto-load on page open — every load/refresh would silently consume
// a RapidAPI request. Posts are only fetched when "Check Source Page Now" is
// clicked, or right after saving a new source URL.
const initialListEl = document.getElementById('posts-list');
if (initialListEl) {
  initialListEl.innerHTML = '<div class="empty-state">Click "Check Source Page Now" To Load Posts.</div>';
}
</script>
</body>
</html>
