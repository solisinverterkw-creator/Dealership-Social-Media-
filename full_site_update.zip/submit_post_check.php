<?php
require_once __DIR__ . '/includes/Auth.php';
Auth::requireLogin();
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/GeminiVisionChecker.php';
require_once __DIR__ . '/includes/ImageResizer.php';
set_time_limit(0); // Gemini's retry loop (5 attempts with backoff) can take several minutes if the model is overloaded

$db = Database::getConnection();
$scopedIds = Auth::dealershipIds();
$isSuperAdmin = Auth::isSuperAdmin();

if ($isSuperAdmin) {
    $accessibleDealerships = $db->query("SELECT id, name FROM dealerships ORDER BY name")->fetchAll();
} elseif (!empty($scopedIds)) {
    $placeholders = implode(',', array_fill(0, count($scopedIds), '?'));
    $stmt = $db->prepare("SELECT id, name FROM dealerships WHERE id IN ($placeholders) ORDER BY name");
    $stmt->execute($scopedIds);
    $accessibleDealerships = $stmt->fetchAll();
} else {
    $accessibleDealerships = [];
}

$message = '';
$error = '';
$latestResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dealershipId = (int)($_POST['dealership_id'] ?? 0);
    $caption = trim($_POST['caption'] ?? '');

    if (!Auth::canAccessDealership($dealershipId)) {
        http_response_code(403);
        exit('You Do Not Have Access To This Dealership.');
    }

    if (empty($_FILES['post_image']['name']) || $_FILES['post_image']['error'] !== UPLOAD_ERR_OK) {
        $error = 'A Post Image Is Required.';
    } else {
        $ext = strtolower(pathinfo($_FILES['post_image']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
            $error = 'Only jpg, png, or webp Images Are Allowed.';
        } else {
            $filename = 'submission_' . uniqid() . '.' . $ext;
            $relativePath = "assets/uploads/submissions/$filename";
            move_uploaded_file($_FILES['post_image']['tmp_name'], __DIR__ . '/' . $relativePath);
            ImageResizer::resizeInPlace(__DIR__ . '/' . $relativePath);

            $insert = $db->prepare("INSERT INTO post_submissions (dealership_id, image_path, caption, status) VALUES (:did, :img, :cap, 'pending')");
            $insert->execute(['did' => $dealershipId, 'img' => $relativePath, 'cap' => $caption]);
            $submissionId = (int)$db->lastInsertId();

            $vehicles = $db->query("SELECT * FROM vehicle_models")->fetchAll();
            foreach ($vehicles as &$v) {
                $imgStmt = $db->prepare("SELECT image_path FROM vehicle_model_images WHERE vehicle_model_id = :vid ORDER BY id");
                $imgStmt->execute(['vid' => $v['id']]);
                $v['images'] = $imgStmt->fetchAll(PDO::FETCH_COLUMN);
            }
            unset($v);
            $identity = $db->query("SELECT * FROM brand_identity WHERE id = 1")->fetch();

            if (empty($vehicles)) {
                $error = 'No Approved Vehicle References Set Up Yet — Ask Your Super Admin To Add Some In "Brand Assets" First.';
            } else {
                $checker = new GeminiVisionChecker();
                $result = $checker->checkCompliance(__DIR__ . '/' . $relativePath, $caption, $vehicles, $identity);

                if (!$result['success']) {
                    $error = 'Check Failed: ' . $result['message'];
                } else {
                    $status = $result['approved'] ? 'approved' : 'rejected';
                    $reasons = implode(' | ', $result['reasons'] ?? []);
                    $db->prepare("UPDATE post_submissions SET status = :status, reasons = :reasons, checked_at = NOW() WHERE id = :id")
                       ->execute(['status' => $status, 'reasons' => $reasons, 'id' => $submissionId]);

                    $latestResult = ['status' => $status, 'reasons' => $result['reasons'] ?? [], 'image' => $relativePath];
                    $message = $result['approved'] ? 'Post Approved.' : 'Post Rejected.';
                }
            }
        }
    }
}

// History list
if ($isSuperAdmin) {
    $history = $db->query("
        SELECT ps.*, d.name AS dealership_name FROM post_submissions ps
        JOIN dealerships d ON d.id = ps.dealership_id
        ORDER BY ps.submitted_at DESC LIMIT 30
    ")->fetchAll();
} elseif (!empty($scopedIds)) {
    $placeholders = implode(',', array_fill(0, count($scopedIds), '?'));
    $stmt = $db->prepare("
        SELECT ps.*, d.name AS dealership_name FROM post_submissions ps
        JOIN dealerships d ON d.id = ps.dealership_id
        WHERE ps.dealership_id IN ($placeholders)
        ORDER BY ps.submitted_at DESC LIMIT 30
    ");
    $stmt->execute($scopedIds);
    $history = $stmt->fetchAll();
} else {
    $history = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<script>(function(){var t=localStorage.getItem('theme');if(t)document.documentElement.setAttribute('data-theme',t);})();</script>
<meta charset="UTF-8">
<title>Post Approval</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#1a1a19">
<link rel="apple-touch-icon" href="assets/icon-192.png">
<script>if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js'));}</script>
</head>
<body>
<div class="app-layout">
<?php require __DIR__ . '/includes/Sidebar.php'; ?>
<main class="main-content">
<div class="container">

  <header>
    <div>
      <h1>Post Approval</h1>
      <div class="subtitle">Submit A Post For Brand-Compliance Checking — Approval Only, Nothing Publishes Automatically</div>
    </div>
  </header>

  <?php if ($message): ?><div class="<?= $error ? 'error-msg' : 'success-msg' ?>"><?= htmlspecialchars($message) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="error-msg"><?= htmlspecialchars($error) ?></div><?php endif; ?>

  <?php if ($latestResult): ?>
  <div class="detail-card" style="margin-bottom:24px; border-color:<?= $latestResult['status'] === 'approved' ? 'var(--green)' : 'var(--red)' ?>;">
    <h2>
      <span class="status-badge <?= $latestResult['status'] === 'approved' ? 'status-done' : 'status-flag' ?>">
        <?= $latestResult['status'] === 'approved' ? '✓ Approved' : '✗ Rejected' ?>
      </span>
    </h2>
    <img src="<?= htmlspecialchars($latestResult['image']) ?>" style="max-width:300px; border-radius:8px; margin:12px 0; display:block;">
    <?php if (!empty($latestResult['reasons'])): ?>
      <ul style="margin:0; padding-left:20px; color:var(--muted); font-size:13px; line-height:1.8;">
        <?php foreach ($latestResult['reasons'] as $r): ?><li><?= htmlspecialchars($r) ?></li><?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <?php if (empty($accessibleDealerships)): ?>
    <div class="empty-state">No Dealership Linked To Your Account.</div>
  <?php else: ?>
  <form method="POST" enctype="multipart/form-data" class="search-panel" style="margin-bottom:28px;">
    <div class="field">
      <label>Dealership</label>
      <select name="dealership_id" required>
        <?php foreach ($accessibleDealerships as $d): ?>
          <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="field">
      <label>Post Image</label>
      <input type="file" name="post_image" accept=".jpg,.jpeg,.png,.webp" required>
    </div>
    <div class="field">
      <label>Caption</label>
      <textarea name="caption" rows="3" placeholder="Post caption text..."></textarea>
    </div>
    <button type="submit" class="submit">Check & Submit</button>
  </form>
  <?php endif; ?>

  <h2 style="font-size:16px; margin-bottom:14px;">Recent Submissions</h2>
  <div class="table-wrap">
    <?php if (empty($history)): ?>
      <div class="empty-state">No Submissions Yet.</div>
    <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Preview</th>
          <th>Dealership</th>
          <th>Caption</th>
          <th>Status</th>
          <th>Reasons</th>
          <th>Submitted</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $h): ?>
        <tr>
          <td><img src="<?= htmlspecialchars($h['image_path']) ?>" style="height:44px; border-radius:4px;"></td>
          <td class="name"><?= htmlspecialchars($h['dealership_name']) ?></td>
          <td class="timestamp" style="max-width:200px; white-space:normal;"><?= htmlspecialchars(mb_substr($h['caption'] ?? '', 0, 60)) ?></td>
          <td>
            <span class="status-badge <?= $h['status'] === 'approved' ? 'status-done' : ($h['status'] === 'rejected' ? 'status-flag' : 'status-pending') ?>">
              <?= ucfirst($h['status']) ?>
            </span>
          </td>
          <td class="timestamp" style="max-width:240px; white-space:normal; color:var(--red);"><?= htmlspecialchars($h['reasons'] ?? '') ?></td>
          <td class="timestamp"><?= date('d M, H:i', strtotime($h['submitted_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

</div>
</main>
</div>
</body>
</html>
