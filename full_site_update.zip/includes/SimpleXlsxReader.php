<?php
/**
 * Minimal .xlsx reader with zero external dependencies — this server's PHP
 * has no `zip` extension, so ZIP entries are located via a hand-rolled central
 * directory parse and decompressed with zlib's gzinflate() (deflate is the
 * standard xlsx compression method).
 * Only pulls cell values containing "@" (candidate emails) — good enough for
 * "here's a spreadsheet, find the emails in it" regardless of which column
 * they're in or whether there's a header row.
 */
class SimpleXlsxReader
{
    public function extractCandidateEmails(string $filePath): array
    {
        $data = file_get_contents($filePath);
        if ($data === false) {
            return [];
        }

        $centralDir = $this->parseCentralDirectory($data);
        if (empty($centralDir)) {
            return [];
        }

        $sheetName = null;
        foreach (array_keys($centralDir) as $name) {
            if ($name === 'xl/worksheets/sheet1.xml') {
                $sheetName = $name;
                break;
            }
        }
        if ($sheetName === null) {
            foreach (array_keys($centralDir) as $name) {
                if (preg_match('#^xl/worksheets/sheet\d+\.xml$#', $name)) {
                    $sheetName = $name;
                    break;
                }
            }
        }
        if ($sheetName === null) {
            return [];
        }

        $sharedStrings = $this->extractSharedStrings($data, $centralDir);
        $sheetXml = $this->extractEntry($data, $centralDir, $sheetName);
        if ($sheetXml === null) {
            return [];
        }

        return $this->extractEmailsFromSheetXml($sheetXml, $sharedStrings);
    }

    private function parseCentralDirectory(string $data): array
    {
        $eocdPos = strrpos($data, "PK\x05\x06");
        if ($eocdPos === false) {
            return [];
        }
        $entryCount = unpack('v', substr($data, $eocdPos + 10, 2))[1];
        $cdOffset = unpack('V', substr($data, $eocdPos + 16, 4))[1];

        $entries = [];
        $pos = $cdOffset;
        for ($i = 0; $i < $entryCount; $i++) {
            if (substr($data, $pos, 4) !== "PK\x01\x02") {
                break;
            }
            $compMethod = unpack('v', substr($data, $pos + 10, 2))[1];
            $compSize = unpack('V', substr($data, $pos + 20, 4))[1];
            $nameLen = unpack('v', substr($data, $pos + 28, 2))[1];
            $extraLen = unpack('v', substr($data, $pos + 30, 2))[1];
            $commentLen = unpack('v', substr($data, $pos + 32, 2))[1];
            $localOffset = unpack('V', substr($data, $pos + 42, 4))[1];
            $name = substr($data, $pos + 46, $nameLen);

            $entries[$name] = [
                'comp_method' => $compMethod,
                'comp_size' => $compSize,
                'local_offset' => $localOffset,
            ];

            $pos += 46 + $nameLen + $extraLen + $commentLen;
        }
        return $entries;
    }

    private function extractEntry(string $data, array $centralDir, string $name): ?string
    {
        if (!isset($centralDir[$name])) {
            return null;
        }
        $entry = $centralDir[$name];
        $pos = $entry['local_offset'];
        if (substr($data, $pos, 4) !== "PK\x03\x04") {
            return null;
        }
        $nameLen = unpack('v', substr($data, $pos + 26, 2))[1];
        $extraLen = unpack('v', substr($data, $pos + 28, 2))[1];
        $dataStart = $pos + 30 + $nameLen + $extraLen;
        $compressed = substr($data, $dataStart, $entry['comp_size']);

        if ($entry['comp_method'] === 0) {
            return $compressed;
        }
        $inflated = @gzinflate($compressed);
        return $inflated !== false ? $inflated : null;
    }

    private function extractSharedStrings(string $data, array $centralDir): array
    {
        $xml = $this->extractEntry($data, $centralDir, 'xl/sharedStrings.xml');
        if ($xml === null) {
            return [];
        }
        $sxml = @simplexml_load_string($xml);
        if (!$sxml) {
            return [];
        }
        $strings = [];
        foreach ($sxml->si as $si) {
            if (isset($si->t)) {
                $strings[] = (string)$si->t;
            } else {
                $text = '';
                foreach ($si->r as $r) {
                    $text .= (string)$r->t;
                }
                $strings[] = $text;
            }
        }
        return $strings;
    }

    private function extractEmailsFromSheetXml(string $xml, array $sharedStrings): array
    {
        $sxml = @simplexml_load_string($xml);
        if (!$sxml || !isset($sxml->sheetData)) {
            return [];
        }
        $values = [];
        foreach ($sxml->sheetData->row as $row) {
            foreach ($row->c as $cell) {
                if (!isset($cell->v)) {
                    continue;
                }
                $type = (string)$cell['t'];
                $raw = (string)$cell->v;
                $value = $type === 's' ? ($sharedStrings[(int)$raw] ?? '') : $raw;
                $value = trim($value);
                if ($value !== '' && str_contains($value, '@')) {
                    $values[] = $value;
                }
            }
        }
        return array_values(array_unique($values));
    }
}
