<?php
require_once __DIR__ . '/../config.php';

class InstagramLookup
{
    private string $host = "instagram-looter2.p.rapidapi.com";

    public function extractUsername(string $input): string
    {
        $input = trim($input);
        if (str_contains($input, 'instagram.com')) {
            $path = trim(parse_url($input, PHP_URL_PATH), '/');
            $parts = explode('/', $path);
            return $parts[0];
        }
        return ltrim($input, '@');
    }

    private function fetchProfile(string $username): array
    {
        $url = "https://{$this->host}/profile?username=" . urlencode($username);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'x-rapidapi-key: ' . RAPIDAPI_KEY,
            'x-rapidapi-host: ' . $this->host,
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return ['httpCode' => $httpCode, 'data' => json_decode($response, true)];
    }

    public function getFollowerCount(string $profileInput): array
    {
        if (empty(trim($profileInput))) {
            return ['success' => false, 'message' => 'Instagram Input Is Empty.'];
        }

        $username = $this->extractUsername($profileInput);
        $result = $this->fetchProfile($username);

        if ($result['httpCode'] !== 200 || empty($result['data']['status'])) {
            return ['success' => false, 'message' => 'Profile Not Found.'];
        }

        return [
            'success' => true,
            'followers' => (int)($result['data']['edge_followed_by']['count'] ?? 0),
        ];
    }

    public function countInRange(string $profileInput, string $fromDate, string $toDate): array
    {
        if (empty(trim($profileInput))) {
            return ['success' => false, 'message' => 'Instagram Input Is Empty.'];
        }

        $username = $this->extractUsername($profileInput);
        $result = $this->fetchProfile($username);

        if ($result['httpCode'] !== 200 || empty($result['data']['status'])) {
            return ['success' => false, 'message' => 'Profile Not Found.'];
        }

        $edges = $result['data']['edge_owner_to_timeline_media']['edges'] ?? [];
        $fromTs = strtotime($fromDate);
        $toTs = strtotime($toDate . ' +1 day');

        $inRange = array_filter($edges, function ($edge) use ($fromTs, $toTs) {
            $ts = $edge['node']['taken_at_timestamp'] ?? null;
            return $ts && $ts >= $fromTs && $ts < $toTs;
        });
        $postCount = count($inRange);

        $totalEngagement = 0;
        foreach ($inRange as $edge) {
            $node = $edge['node'];
            $totalEngagement += (int)($node['edge_media_preview_like']['count'] ?? 0)
                              + (int)($node['edge_media_to_comment']['count'] ?? 0);
        }
        $avgEngagement = $postCount > 0 ? round($totalEngagement / $postCount, 2) : 0;

        return [
            'success' => true,
            'count' => $postCount,
            'avg_engagement' => $avgEngagement,
        ];
    }
}
