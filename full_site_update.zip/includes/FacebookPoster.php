<?php
require_once __DIR__ . '/../config.php';

class FacebookPoster
{
    private string $baseUrl;

    public function __construct()
    {
        $this->baseUrl = "https://graph.facebook.com/" . FB_GRAPH_API_VERSION;
    }

    private function request(string $method, string $path, array $params): array
    {
        $url = "{$this->baseUrl}{$path}";
        $ch = curl_init();

        if ($method === 'GET') {
            curl_setopt($ch, CURLOPT_URL, $url . '?' . http_build_query($params));
        } else {
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        return ['httpCode' => $httpCode, 'data' => $data];
    }

    public function getRecentPosts(string $pageId, string $token, int $limit = 10): array
    {
        $result = $this->request('GET', "/{$pageId}/posts", [
            'fields' => 'id,message,full_picture,created_time',
            'limit' => $limit,
            'access_token' => $token,
        ]);

        if ($result['httpCode'] !== 200 || !isset($result['data']['data'])) {
            $message = $result['data']['error']['message'] ?? ('HTTP ' . $result['httpCode']);
            return ['success' => false, 'message' => $message];
        }

        return ['success' => true, 'posts' => $result['data']['data']];
    }

    public function getPost(string $postId, string $token): array
    {
        $result = $this->request('GET', "/{$postId}", [
            'fields' => 'message,full_picture,created_time',
            'access_token' => $token,
        ]);

        if ($result['httpCode'] !== 200 || isset($result['data']['error'])) {
            $errorMessage = $result['data']['error']['message'] ?? ('HTTP ' . $result['httpCode']);
            return ['success' => false, 'message' => $errorMessage];
        }

        return [
            'success' => true,
            'message' => $result['data']['message'] ?? '',
            'image_url' => $result['data']['full_picture'] ?? null,
        ];
    }

    public function publishToPage(string $pageId, string $token, string $message, ?string $imageUrl, ?string $videoUrl = null): array
    {
        if (!empty($videoUrl)) {
            $result = $this->request('POST', "/{$pageId}/videos", [
                'file_url' => $videoUrl,
                'description' => $message,
                'access_token' => $token,
            ]);
            $postIdField = 'id';
        } elseif (!empty($imageUrl)) {
            $result = $this->request('POST', "/{$pageId}/photos", [
                'url' => $imageUrl,
                'caption' => $message,
                'access_token' => $token,
            ]);
            $postIdField = 'post_id';
        } else {
            $result = $this->request('POST', "/{$pageId}/feed", [
                'message' => $message,
                'access_token' => $token,
            ]);
            $postIdField = 'id';
        }

        if ($result['httpCode'] !== 200 || empty($result['data'][$postIdField])) {
            $errorMessage = $result['data']['error']['message'] ?? ('HTTP ' . $result['httpCode']);
            return ['success' => false, 'message' => $errorMessage];
        }

        return ['success' => true, 'fb_post_id' => $result['data'][$postIdField]];
    }

    /**
     * Parses common Facebook post URL shapes into a Graph API-usable ID.
     * Returns null if the URL doesn't match a known pattern.
     */
    public function extractPostId(string $url): ?string
    {
        $url = trim($url);

        // https://www.facebook.com/{page}/posts/{post_id}
        if (preg_match('#/posts/([a-zA-Z0-9]+)#', $url, $m)) {
            return $m[1];
        }

        // https://www.facebook.com/{page}/videos/{video_id}
        if (preg_match('#/videos/(\d+)#', $url, $m)) {
            return $m[1];
        }

        // https://www.facebook.com/reel/{reel_id}
        if (preg_match('#/reel/(\d+)#', $url, $m)) {
            return $m[1];
        }

        // https://www.facebook.com/story.php?story_fbid=X&id=Y  or  /permalink.php?story_fbid=X&id=Y
        $query = parse_url($url, PHP_URL_QUERY);
        if ($query) {
            parse_str($query, $params);
            if (!empty($params['story_fbid']) && !empty($params['id'])) {
                return $params['id'] . '_' . $params['story_fbid'];
            }
        }

        return null;
    }
}
