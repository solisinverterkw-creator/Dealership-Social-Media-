<?php
require_once __DIR__ . '/../config.php';

class GeminiVisionChecker
{
    private string $model = 'gemini-3-flash-preview';

    private function encodeImage(string $path): ?array
    {
        if (!file_exists($path)) {
            return null;
        }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $mime = match ($ext) {
            'png' => 'image/png',
            'webp' => 'image/webp',
            default => 'image/jpeg',
        };
        return [
            'inline_data' => [
                'mime_type' => $mime,
                'data' => base64_encode(file_get_contents($path)),
            ],
        ];
    }

    /**
     * Sends the submitted post image + all approved reference assets (vehicle
     * photos, logo variants, tagline) to Gemini in one call and asks it to
     * check every rule at once — logo variant vs background brightness, every
     * visible car part (rims, lights, etc.) matching an approved reference,
     * and the tagline. Approval-only: never publishes anything itself.
     *
     * $vehicleModels: rows from vehicle_models (name, color) each with an
     * 'images' array (up to 10 reference photo paths — different angles/parts
     * like front, rear, rim, bumper, side mirror, fuel tank cap, etc.) so a
     * mismatched part is caught even if it's not visible in a single photo.
     * $identity: row from brand_identity (logo_light_path, logo_dark_path, tagline,
     * primary_color, secondary_color, website_url).
     */
    public function checkCompliance(string $submittedImagePath, string $caption, array $vehicleModels, $identity): array
    {
        $identity = $identity ?: null; // PDO::fetch() returns false (not null) when brand_identity has no row yet
        $parts = [];

        $ruleNum = 1;
        $promptLines = [
            "You are a strict brand-compliance checker for a car dealership's social media post.",
            "Check the SUBMITTED POST IMAGE (the last image below) against ALL of these rules, using the earlier reference images as ground truth:",
            "",
        ];
        if (!empty($vehicleModels)) {
            $promptLines[] = ($ruleNum++) . ". VEHICLE MATCH: The car in the submitted image must match one of the approved reference vehicles EXACTLY. Each approved vehicle below is shown across MULTIPLE reference photos covering different angles/parts (front, rear, rim, bumper, side mirror, fuel tank cap, headlights/taillights, badges, etc.) — use ALL of a vehicle's photos together as the ground truth for that vehicle, not just one. If any visible part in the submitted image differs from every reference photo of that vehicle (wrong rim, wrong bumper shape, wrong side mirror, wrong fuel tank cap, wrong light shape, wrong badge, edited/mismatched part, or a completely different/unapproved vehicle), REJECT and name the specific mismatched part.";
        }
        $hasLogo = !empty($identity['logo_light_path']) || !empty($identity['logo_dark_path']);
        if ($hasLogo) {
            $promptLines[] = ($ruleNum++) . ". LOGO RULE: If the submitted image's background is predominantly DARK, the LIGHT logo variant must be visible on it. If the background is predominantly LIGHT, the DARK logo variant must be visible. Only apply this rule for whichever variant(s) were actually provided as reference below — do not reject for a missing variant that has no reference image. Wrong variant = REJECT.";
        }
        if (!empty($identity['tagline'])) {
            $promptLines[] = ($ruleNum++) . ". TAGLINE: The post caption should include or closely reflect this tagline: \"{$identity['tagline']}\". Missing it = REJECT.";
        }
        $brandColors = array_filter([$identity['primary_color'] ?? null, $identity['secondary_color'] ?? null]);
        if (!empty($brandColors)) {
            $colorList = implode(' and ', $brandColors);
            $promptLines[] = ($ruleNum++) . ". BRAND COLOR: The submitted image's graphic design elements (background, text overlays, banners, branding accents — NOT the vehicle's own paint color) should prominently use the brand color(s): {$colorList}. If the design clearly ignores these brand colors in favor of unrelated ones, REJECT.";
        }
        if (!empty($identity['website_url'])) {
            $promptLines[] = ($ruleNum++) . ". WEBSITE: The post caption should include or closely reflect this website: \"{$identity['website_url']}\". Missing it = REJECT.";
        }
        if ($ruleNum === 1) {
            // No rules configured yet at all.
            $promptLines[] = "No compliance rules are configured yet — approve by default and note that no reference data exists.";
        }
        $promptLines[] = "";
        $promptLines[] = "Submitted post caption: \"" . ($caption !== '' ? $caption : '(no caption)') . "\"";
        $promptLines[] = "";
        $promptLines[] = "Reference images below, in order:";

        $refIndex = 1;
        foreach ($vehicleModels as $v) {
            $images = $v['images'] ?? (!empty($v['reference_image']) ? [$v['reference_image']] : []);
            foreach ($images as $imagePath) {
                $encoded = $this->encodeImage(__DIR__ . '/../' . $imagePath);
                if ($encoded) {
                    $promptLines[] = "Reference image {$refIndex}: approved vehicle — {$v['name']}, color {$v['color']} (one of " . count($images) . " reference photos of this vehicle).";
                    $refIndex++;
                }
            }
        }
        if (!empty($identity['logo_light_path'])) {
            $encoded = $this->encodeImage(__DIR__ . '/../' . $identity['logo_light_path']);
            if ($encoded) {
                $promptLines[] = "Reference image {$refIndex}: LIGHT logo variant (for dark backgrounds).";
                $refIndex++;
            }
        }
        if (!empty($identity['logo_dark_path'])) {
            $encoded = $this->encodeImage(__DIR__ . '/../' . $identity['logo_dark_path']);
            if ($encoded) {
                $promptLines[] = "Reference image {$refIndex}: DARK logo variant (for light backgrounds).";
                $refIndex++;
            }
        }
        $promptLines[] = "";
        $promptLines[] = "Last image below is the SUBMITTED POST IMAGE to judge.";
        $promptLines[] = "";
        $promptLines[] = 'Respond with ONLY this JSON, no other text: {"approved": true|false, "reasons": ["specific reason 1", "..."]}';
        $promptLines[] = 'If approved with no issues, reasons should be an empty array.';

        $parts[] = ['text' => implode("\n", $promptLines)];

        foreach ($vehicleModels as $v) {
            $images = $v['images'] ?? (!empty($v['reference_image']) ? [$v['reference_image']] : []);
            foreach ($images as $imagePath) {
                $encoded = $this->encodeImage(__DIR__ . '/../' . $imagePath);
                if ($encoded) {
                    $parts[] = $encoded;
                }
            }
        }
        if (!empty($identity['logo_light_path'])) {
            $encoded = $this->encodeImage(__DIR__ . '/../' . $identity['logo_light_path']);
            if ($encoded) {
                $parts[] = $encoded;
            }
        }
        if (!empty($identity['logo_dark_path'])) {
            $encoded = $this->encodeImage(__DIR__ . '/../' . $identity['logo_dark_path']);
            if ($encoded) {
                $parts[] = $encoded;
            }
        }

        $submittedEncoded = $this->encodeImage($submittedImagePath);
        if (!$submittedEncoded) {
            return ['success' => false, 'message' => 'Submitted image could not be read.'];
        }
        $parts[] = $submittedEncoded;

        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key=" . GEMINI_API_KEY;
        $body = json_encode([
            'contents' => [['parts' => $parts]],
            'generationConfig' => ['response_mime_type' => 'application/json'],
        ]);

        // gemini-3-flash-preview (a preview/beta model) periodically returns a
        // transient 503 "high demand" error, or the connection is dropped
        // outright under sustained overload (curl reports HTTP 0) — retry with
        // increasing backoff before giving up. 503/0 are explicitly retryable
        // per Google's own error message; a real 4xx (bad request, auth) won't
        // change on retry, but retrying it a few times costs little.
        $httpCode = 0;
        $response = null;
        $backoffSeconds = [5, 10, 20, 30, 30];
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($httpCode === 200) {
                break;
            }
            sleep($backoffSeconds[$attempt] ?? 30);
        }

        if ($httpCode !== 200) {
            $data = json_decode($response, true);
            $message = $data['error']['message']
                ?? ($httpCode === 0
                    ? 'Could Not Reach Gemini (Connection Failed Or Timed Out) After 5 Attempts — The Model May Be Overloaded. Please Try Again In A Few Minutes.'
                    : "HTTP {$httpCode}");
            return ['success' => false, 'message' => $message];
        }

        $data = json_decode($response, true);
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
        if (!$text) {
            return ['success' => false, 'message' => 'No response from Gemini.'];
        }

        $result = json_decode($text, true);
        if (!is_array($result) || !isset($result['approved'])) {
            return ['success' => false, 'message' => 'Could not parse Gemini response: ' . mb_substr($text, 0, 200)];
        }

        return [
            'success' => true,
            'approved' => (bool)$result['approved'],
            'reasons' => $result['reasons'] ?? [],
        ];
    }
}
