<?php
// Canonical list of sidebar sections a scoped (non-super-admin) user can be
// granted or denied access to. Keys are stored in user_sidebar_sections.
// change_password.php and the super-admin-only links (brand_assets.php,
// users.php) are intentionally excluded — every logged-in user always keeps
// change_password, and the other two stay hard-gated to super admins.
function sidebarSectionsList(): array
{
    return [
        'dashboard'           => ['label' => 'Dashboard', 'page' => 'index.php'],
        'report'              => ['label' => 'Social Media Report', 'page' => 'report.php'],
        'weekly_posts'        => ['label' => 'Posting Activity', 'page' => 'weekly_posts.php'],
        'yt_monthly'          => ['label' => 'YT Monthly Videos', 'page' => 'yt_monthly.php'],
        'no_activity_report'  => ['label' => 'Follower Activity Report', 'page' => 'no_activity_report.php'],
        'manual_publish'      => ['label' => 'Publish Content', 'page' => 'manual_publish.php'],
        'syndication_report'  => ['label' => 'Integration Report', 'page' => 'syndication_report.php'],
        'post_breakdown'      => ['label' => 'Post Breakdown Report', 'page' => 'post_breakdown_report.php'],
        'reshare_compliance'  => ['label' => 'Reshare Compliance', 'page' => 'reshare_compliance_report.php'],
        'target_pages'        => ['label' => 'Target Pages', 'page' => 'target_pages.php'],
        'submit_post_check'   => ['label' => 'Post Approval', 'page' => 'submit_post_check.php'],
        'email_validator'     => ['label' => 'Email Validator', 'page' => 'email_validator.php'],
    ];
}
