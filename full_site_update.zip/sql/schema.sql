CREATE DATABASE IF NOT EXISTS dealership_dashboard CHARACTER SET utf8mb4;
USE dealership_dashboard;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_super_admin TINYINT(1) NOT NULL DEFAULT 0,  -- super admin bypasses user_dealerships + all can_* flags entirely
    can_refresh TINYINT(1) NOT NULL DEFAULT 1,     -- trigger FB/IG/YT/Google refresh + reshare compliance checks
    can_edit TINYINT(1) NOT NULL DEFAULT 0,        -- edit dealership search inputs (edit_dealership.php)
    can_delete TINYINT(1) NOT NULL DEFAULT 0,      -- delete a dealership they're assigned to
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dealerships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,

    -- search inputs (aap ek baar set karein)
    fb_input VARCHAR(255) NULL,        -- FB page ka exact URL ya username
    ig_search VARCHAR(255) NULL,       -- IG profile ka URL ya @username
    yt_search VARCHAR(255) NULL,       -- YouTube channel ka naam
    google_search VARCHAR(255) NULL,   -- Google business ka naam + city

    -- Facebook (auto via RapidAPI)
    fb_page_id VARCHAR(50) NULL,       -- resolve once, reuse (saves a request on every future check)
    fb_followers INT DEFAULT 0,
    fb_target INT DEFAULT 0,           -- super-admin-set goal; used for % achieved in reports

    -- Instagram (auto via Apify)
    ig_followers INT DEFAULT 0,
    ig_target INT DEFAULT 0,
    ig_updated_at DATETIME NULL,

    -- YouTube (auto)
    yt_channel_id VARCHAR(50) NULL,    -- resolve once, reuse (naam-search har baar consistent nahi hoti)
    yt_subscribers INT DEFAULT 0,
    yt_target INT DEFAULT 0,
    yt_videos INT DEFAULT 0,
    yt_views BIGINT DEFAULT 0,

    -- Google Reviews (auto)
    google_review_count INT DEFAULT 0,
    google_review_target INT DEFAULT 0,
    google_rating DECIMAL(2,1) DEFAULT 0,

    -- Weekly Facebook post count + avg engagement per post (auto via Apify)
    fb_posts_week INT DEFAULT 0,
    fb_engagement_avg DECIMAL(10,2) DEFAULT 0,
    fb_posts_checked_at DATETIME NULL,

    -- Weekly Instagram post count + avg engagement per post (auto via Apify)
    ig_posts_week INT DEFAULT 0,
    ig_engagement_avg DECIMAL(10,2) DEFAULT 0,
    ig_posts_checked_at DATETIME NULL,

    -- Monthly YouTube video uploads (auto via YouTube Data API)
    yt_videos_month INT DEFAULT 0,
    yt_videos_checked_at DATETIME NULL,

    last_refreshed DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- A scoped (non-super-admin) user can be assigned to more than one dealership.
CREATE TABLE user_dealerships (
    user_id INT NOT NULL,
    dealership_id INT NOT NULL,
    PRIMARY KEY (user_id, dealership_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (dealership_id) REFERENCES dealerships(id) ON DELETE CASCADE
);

-- Which sidebar sections a scoped (non-super-admin) user can see, set per user
-- from Edit User. Keys match includes/SidebarSections.php. A super admin
-- bypasses this entirely and always sees every section.
CREATE TABLE user_sidebar_sections (
    user_id INT NOT NULL,
    section_key VARCHAR(50) NOT NULL,
    PRIMARY KEY (user_id, section_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE yt_monthly_stats (
    dealership_id INT NOT NULL,
    month CHAR(7) NOT NULL,           -- e.g. '2026-07'
    video_count INT NOT NULL DEFAULT 0,
    PRIMARY KEY (dealership_id, month),
    FOREIGN KEY (dealership_id) REFERENCES dealerships(id) ON DELETE CASCADE
);

-- ---------- Facebook Content Syndication (official Graph API, admin-owned pages only) ----------

CREATE TABLE target_pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    page_id VARCHAR(50) NOT NULL,
    page_access_token TEXT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    dealership_id INT NULL,     -- links this target page to a dealerships.id for scoped-user access
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE processed_source_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_post_id VARCHAR(50) NOT NULL UNIQUE,
    message_snippet VARCHAR(255) NULL,
    published_at DATETIME NULL,   -- the post's actual publish date — used for date-range filtering + grace period
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app_settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT NULL
);

-- Tracks, per dealership per known source post, whether that dealership has
-- reshared it on their own (RapidAPI-scraped) page — independent of whether
-- Content Syndication (target_pages/Zapier) actually published it there.
CREATE TABLE reshare_checks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dealership_id INT NOT NULL,
    source_post_id VARCHAR(50) NOT NULL,
    message_snippet VARCHAR(255) NULL,
    first_seen_at DATETIME NOT NULL,     -- when our system first checked this pairing (diagnostic only)
    published_at DATETIME NULL,          -- the source post's real publish date — used for range filtering + grace period
    reshared TINYINT(1) NOT NULL DEFAULT 0,
    reshared_detected_at DATETIME NULL,
    last_checked_at DATETIME NULL,
    UNIQUE KEY dealership_post (dealership_id, source_post_id),
    FOREIGN KEY (dealership_id) REFERENCES dealerships(id) ON DELETE CASCADE
);

-- Own-vs-reshare post counts for a dealership's page, computed fresh (fully
-- paginated over the selected date range) each time "Check" runs — overwritten
-- on every check, always reflecting the most recently checked range.
CREATE TABLE reshare_own_post_stats (
    dealership_id INT PRIMARY KEY,
    range_from DATE NOT NULL,
    range_to DATE NOT NULL,
    own_post_count INT NOT NULL DEFAULT 0,
    reshare_post_count INT NOT NULL DEFAULT 0,
    checked_at DATETIME NOT NULL,
    FOREIGN KEY (dealership_id) REFERENCES dealerships(id) ON DELETE CASCADE
);

-- ---------- Brand Compliance Checker (Gemini vision) ----------

-- Reference photos per approved vehicle model + color, used as the "ground
-- truth" a dealership's submitted post photo is compared against (rims,
-- lights, and every other visible part must match one of these).
CREATE TABLE vehicle_models (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    color VARCHAR(50) NOT NULL,
    reference_image VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Multiple reference photos per vehicle model (up to 10) — different
-- angles/parts (rim, bumper, side mirror, fuel tank cap, etc.) so the
-- compliance checker has enough ground truth to catch a mismatched part.
CREATE TABLE vehicle_model_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_model_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_model_id) REFERENCES vehicle_models(id) ON DELETE CASCADE
);

-- Single-row table: logo variants (for light/dark backgrounds) + tagline.
CREATE TABLE brand_identity (
    id INT PRIMARY KEY DEFAULT 1,
    logo_light_path VARCHAR(255) NULL,
    logo_dark_path VARCHAR(255) NULL,
    tagline VARCHAR(255) NULL,
    primary_color VARCHAR(100) NULL,
    secondary_color VARCHAR(100) NULL,
    website_url VARCHAR(255) NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- A dealership-submitted post (image + caption) awaiting/having gone through
-- the Gemini compliance check. Approval only — no auto-publish.
CREATE TABLE post_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dealership_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    caption TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    reasons TEXT NULL,
    checked_at DATETIME NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dealership_id) REFERENCES dealerships(id) ON DELETE CASCADE
);

CREATE TABLE post_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_post_id VARCHAR(50) NULL,
    source_url VARCHAR(500) NULL,
    message TEXT NULL,
    dealership_name VARCHAR(150) NOT NULL,
    target_page_id VARCHAR(50) NOT NULL,
    fb_post_id VARCHAR(100) NULL,
    status ENUM('success','failed') NOT NULL,
    error_message VARCHAR(500) NULL,
    posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
