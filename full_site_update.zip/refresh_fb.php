<?php
header('Content-Type: application/json');
require_once __DIR__ . '/includes/Auth.php';
if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit;
}
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/FacebookLookup.php';
set_time_limit(0); // Bright Data can take longer than PHP's default execution limit if it falls back to polling

$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID missing']);
    exit;
}
if (!Auth::canAccessDealership((int)$id)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}
if (!Auth::can('refresh')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You Do Not Have Permission To Refresh Data.']);
    exit;
}

$db = Database::getConnection();
$stmt = $db->prepare("SELECT fb_input, fb_followers FROM dealerships WHERE id = :id");
$stmt->execute(['id' => $id]);
$d = $stmt->fetch();

if (!$d) {
    echo json_encode(['success' => false, 'message' => 'Dealership Not Found']);
    exit;
}

if (empty($d['fb_input'])) {
    echo json_encode(['success' => true, 'skipped' => true, 'fb_followers' => (int)$d['fb_followers']]);
    exit;
}

$fb = (new FacebookLookup())->getFollowerCount($d['fb_input']);
if (!$fb['success']) {
    echo json_encode(['success' => false, 'message' => $fb['message'], 'fb_followers' => (int)$d['fb_followers']]);
    exit;
}

$db->prepare("UPDATE dealerships SET fb_followers = :v, fb_page_id = COALESCE(fb_page_id, :page_id), last_refreshed = NOW() WHERE id = :id")
   ->execute(['v' => $fb['followers'], 'page_id' => $fb['page_id'], 'id' => $id]);

echo json_encode(['success' => true, 'fb_followers' => $fb['followers']]);
